```python
# Import necessary libraries
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
```


```python
#Load the dataset
data= pd.read_csv("C:\\Users\\Sai Akhil\\OneDrive\\Desktop\\conference\\heart.csv")
```


```python
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalach</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>52</td>
      <td>1</td>
      <td>0</td>
      <td>125</td>
      <td>212</td>
      <td>0</td>
      <td>1</td>
      <td>168</td>
      <td>0</td>
      <td>1.0</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>53</td>
      <td>1</td>
      <td>0</td>
      <td>140</td>
      <td>203</td>
      <td>1</td>
      <td>0</td>
      <td>155</td>
      <td>1</td>
      <td>3.1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>70</td>
      <td>1</td>
      <td>0</td>
      <td>145</td>
      <td>174</td>
      <td>0</td>
      <td>1</td>
      <td>125</td>
      <td>1</td>
      <td>2.6</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>61</td>
      <td>1</td>
      <td>0</td>
      <td>148</td>
      <td>203</td>
      <td>0</td>
      <td>1</td>
      <td>161</td>
      <td>0</td>
      <td>0.0</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>62</td>
      <td>0</td>
      <td>0</td>
      <td>138</td>
      <td>294</td>
      <td>1</td>
      <td>1</td>
      <td>106</td>
      <td>0</td>
      <td>1.9</td>
      <td>1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1020</th>
      <td>59</td>
      <td>1</td>
      <td>1</td>
      <td>140</td>
      <td>221</td>
      <td>0</td>
      <td>1</td>
      <td>164</td>
      <td>1</td>
      <td>0.0</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1021</th>
      <td>60</td>
      <td>1</td>
      <td>0</td>
      <td>125</td>
      <td>258</td>
      <td>0</td>
      <td>0</td>
      <td>141</td>
      <td>1</td>
      <td>2.8</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1022</th>
      <td>47</td>
      <td>1</td>
      <td>0</td>
      <td>110</td>
      <td>275</td>
      <td>0</td>
      <td>0</td>
      <td>118</td>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1023</th>
      <td>50</td>
      <td>0</td>
      <td>0</td>
      <td>110</td>
      <td>254</td>
      <td>0</td>
      <td>0</td>
      <td>159</td>
      <td>0</td>
      <td>0.0</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1024</th>
      <td>54</td>
      <td>1</td>
      <td>0</td>
      <td>120</td>
      <td>188</td>
      <td>0</td>
      <td>1</td>
      <td>113</td>
      <td>0</td>
      <td>1.4</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>1025 rows × 14 columns</p>
</div>




```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalach</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>52</td>
      <td>1</td>
      <td>0</td>
      <td>125</td>
      <td>212</td>
      <td>0</td>
      <td>1</td>
      <td>168</td>
      <td>0</td>
      <td>1.0</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>53</td>
      <td>1</td>
      <td>0</td>
      <td>140</td>
      <td>203</td>
      <td>1</td>
      <td>0</td>
      <td>155</td>
      <td>1</td>
      <td>3.1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>70</td>
      <td>1</td>
      <td>0</td>
      <td>145</td>
      <td>174</td>
      <td>0</td>
      <td>1</td>
      <td>125</td>
      <td>1</td>
      <td>2.6</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>61</td>
      <td>1</td>
      <td>0</td>
      <td>148</td>
      <td>203</td>
      <td>0</td>
      <td>1</td>
      <td>161</td>
      <td>0</td>
      <td>0.0</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>62</td>
      <td>0</td>
      <td>0</td>
      <td>138</td>
      <td>294</td>
      <td>1</td>
      <td>1</td>
      <td>106</td>
      <td>0</td>
      <td>1.9</td>
      <td>1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalach</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1025.000000</td>
      <td>1025.000000</td>
      <td>1025.000000</td>
      <td>1025.000000</td>
      <td>1025.00000</td>
      <td>1025.000000</td>
      <td>1025.000000</td>
      <td>1025.000000</td>
      <td>1025.000000</td>
      <td>1025.000000</td>
      <td>1025.000000</td>
      <td>1025.000000</td>
      <td>1025.000000</td>
      <td>1025.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>54.434146</td>
      <td>0.695610</td>
      <td>0.942439</td>
      <td>131.611707</td>
      <td>246.00000</td>
      <td>0.149268</td>
      <td>0.529756</td>
      <td>149.114146</td>
      <td>0.336585</td>
      <td>1.071512</td>
      <td>1.385366</td>
      <td>0.754146</td>
      <td>2.323902</td>
      <td>0.513171</td>
    </tr>
    <tr>
      <th>std</th>
      <td>9.072290</td>
      <td>0.460373</td>
      <td>1.029641</td>
      <td>17.516718</td>
      <td>51.59251</td>
      <td>0.356527</td>
      <td>0.527878</td>
      <td>23.005724</td>
      <td>0.472772</td>
      <td>1.175053</td>
      <td>0.617755</td>
      <td>1.030798</td>
      <td>0.620660</td>
      <td>0.500070</td>
    </tr>
    <tr>
      <th>min</th>
      <td>29.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>94.000000</td>
      <td>126.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>71.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>48.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>120.000000</td>
      <td>211.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>132.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>56.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>130.000000</td>
      <td>240.00000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>152.000000</td>
      <td>0.000000</td>
      <td>0.800000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>61.000000</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>140.000000</td>
      <td>275.00000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>166.000000</td>
      <td>1.000000</td>
      <td>1.800000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>3.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>77.000000</td>
      <td>1.000000</td>
      <td>3.000000</td>
      <td>200.000000</td>
      <td>564.00000</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>202.000000</td>
      <td>1.000000</td>
      <td>6.200000</td>
      <td>2.000000</td>
      <td>4.000000</td>
      <td>3.000000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(data.columns)
```

    Index(['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg', 'thalach',
           'exang', 'oldpeak', 'slope', 'ca', 'thal', 'target'],
          dtype='object')
    


```python
data.isnull().sum()
```




    age         0
    sex         0
    cp          0
    trestbps    0
    chol        0
    fbs         0
    restecg     0
    thalach     0
    exang       0
    oldpeak     0
    slope       0
    ca          0
    thal        0
    target      0
    dtype: int64




```python
# Visualize the target variable distribution
plt.figure(figsize=(8, 5))
sns.countplot(x='target', data=data, palette='viridis')
plt.title('Distribution of Target Variable (Heart Disease)')
plt.xlabel('Heart Disease (1 = Yes, 0 = No)')
plt.ylabel('Count')
plt.show()
```


    
![png](output_7_0.png)
    



```python
# Correlation heatmap to understand feature relationships
plt.figure(figsize=(14, 10))
sns.heatmap(data.corr(), annot=True, cmap='coolwarm', fmt='.2f')
plt.title('Correlation Heatmap')
plt.show()
```


    
![png](output_8_0.png)
    



```python
#Preprocess the data
# Separate features (X) and target variable (y)
X = data.drop(columns=['target'])  # Features
y = data['target']  # Target (1 = Heart Disease, 0 = No Heart Disease)
```


```python
# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
```


```python
# Scale the features for better model performance
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
```


```python
#Train the Logistic Regression Model
model = LogisticRegression(random_state=42)
model.fit(X_train, y_train)
```




    LogisticRegression(random_state=42)




```python
# Make predictions on the test set
y_pred_train = model.predict(X_train)  # Predictions on training data
y_pred_test = model.predict(X_test)    # Predictions on test data

```


```python
#Evaluate the model
# Calculate accuracy on training data
train_accuracy = accuracy_score(y_train, y_pred_train)
print(f'\nTraining Accuracy: {train_accuracy * 100:.2f}%')
# Calculate accuracy on test data
test_accuracy = accuracy_score(y_test, y_pred_test)
print(f'Testing Accuracy: {test_accuracy * 100:.2f}%')

```

    
    Training Accuracy: 87.20%
    Testing Accuracy: 79.51%
    


```python
# Print classification report for detailed metrics
print("\nClassification Report (Testing Data):")
print(classification_report(y_test, y_pred_test))

```

    
    Classification Report (Testing Data):
                  precision    recall  f1-score   support
    
               0       0.85      0.72      0.78       102
               1       0.76      0.87      0.81       103
    
        accuracy                           0.80       205
       macro avg       0.80      0.79      0.79       205
    weighted avg       0.80      0.80      0.79       205
    
    


```python
# Print confusion matrix to see true positives, false positives, etc.
print("\nConfusion Matrix (Testing Data):")
cm = confusion_matrix(y_test, y_pred_test)
print(cm)
```

    
    Confusion Matrix (Testing Data):
    [[73 29]
     [13 90]]
    


```python
# Plot the confusion matrix using seaborn heatmap
plt.figure(figsize=(6, 5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False)
plt.title('Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.show()
```


    
![png](output_17_0.png)
    



```python
#  Predict on a new sample (Example)
# Define a new sample with appropriate feature values
# [age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal]
new_sample = [[34, 0, 1, 118, 210, 0, 1, 192, 0, 0.7, 2, 0, 2]]  # Example features

# Scale the new sample using the same scaler used on training data
new_sample_scaled = scaler.transform(new_sample)  # Don't forget to scale new samples

# Predict using the trained model
prediction = model.predict(new_sample_scaled)

# Output the prediction result
if prediction == 1:
    print("The patient is predicted to have heart disease.")
else:
    print("The patient is predicted not to have heart disease.")

```

    The patient is predicted to have heart disease.
    


```python
##Explanation of the sample values:
##age: 30 (younger individuals generally have a lower risk).
##sex: 0 (female, typically a lower risk factor).
##cp: 0 (no chest pain, which decreases risk).
##trestbps: 120 (normal resting blood pressure).
##chol: 180 (lower cholesterol level).
##fbs: 0 (fasting blood sugar not elevated).
##restecg: 1 (normal results from resting electrocardiographic test).
##thalach: 170 (higher maximum heart rate during exercise).
##exang: 0 (no exercise-induced angina).
##ldpeak: 0.0 (no ST depression during exercise).
##slope: 2 (slope of the peak exercise ST segment, normal).
##ca: 0 (no major vessels colored by fluoroscopy).
##thal: 2 (normal thalassemia result).
```


```python
new_sample = [[60,1,0,125,258,0,0,141,1,2.8,1,1,3]]  
new_sample_scaled = scaler.transform(new_sample)
prediction = model.predict(new_sample_scaled)
if prediction == 0:
    print("The patient is predicted not to have heart disease.")
else:
    print("The patient is predicted to have heart disease.")

```

    The patient is predicted not to have heart disease.
    


```python

```


```python

```


```python

```


```python

```


```python
# Define a function that predicts heart disease based on cholesterol thresholds
def predict_based_on_cholesterol_threshold(cholesterol_value):
    """
    This function predicts heart disease based on cholesterol levels:
    - Cholesterol < 150: No heart disease
    - Cholesterol >= 150: Heart disease
    """
    if cholesterol_value < 150:
        print(f"Cholesterol level = {cholesterol_value}: The patient is predicted not to have heart disease.")
    else:
        print(f"Cholesterol level = {cholesterol_value}: The patient is predicted to have heart disease.")

# Example: Checking predictions for different cholesterol levels
for chol_level in [100, 120, 140, 150, 160, 180, 200, 220, 250]:
    predict_based_on_cholesterol_threshold(chol_level)

```

    Cholesterol level = 100: The patient is predicted not to have heart disease.
    Cholesterol level = 120: The patient is predicted not to have heart disease.
    Cholesterol level = 140: The patient is predicted not to have heart disease.
    Cholesterol level = 150: The patient is predicted to have heart disease.
    Cholesterol level = 160: The patient is predicted to have heart disease.
    Cholesterol level = 180: The patient is predicted to have heart disease.
    Cholesterol level = 200: The patient is predicted to have heart disease.
    Cholesterol level = 220: The patient is predicted to have heart disease.
    Cholesterol level = 250: The patient is predicted to have heart disease.
    


```python
# Define a function that predicts heart disease based on changing cholesterol levels
def predict_with_normal_features(cholesterol_value):
    """
    This function predicts heart disease while keeping all other features at normal levels.
    The only changing feature is cholesterol.
    """
    # Set features to normal levels as per your explanation
    # [age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal]
    new_sample = [
        [30, 0, 0, 120, cholesterol_value, 0, 1, 170, 0, 0.0, 2, 0, 2]  # Normal feature values
    ]
    
    # Scale the new sample using the same scaler
    new_sample_scaled = scaler.transform(new_sample)

    # Predict using the trained model
    prediction = model.predict(new_sample_scaled)

    # Output the prediction result
    if prediction[0] == 0:
        print(f"Cholesterol level = {cholesterol_value}: The patient is predicted not to have heart disease.")
    else:
        print(f"Cholesterol level = {cholesterol_value}: The patient is predicted to have heart disease.")

# Example: Checking predictions for different cholesterol levels
for chol_level in [40, 140, 150, 160, 180, 200, 220]:
    predict_with_normal_features(chol_level)

```

    Cholesterol level = 40: The patient is predicted to have heart disease.
    Cholesterol level = 140: The patient is predicted to have heart disease.
    Cholesterol level = 150: The patient is predicted to have heart disease.
    Cholesterol level = 160: The patient is predicted to have heart disease.
    Cholesterol level = 180: The patient is predicted to have heart disease.
    Cholesterol level = 200: The patient is predicted to have heart disease.
    Cholesterol level = 220: The patient is predicted to have heart disease.
    


```python
# Assuming model is already trained and we have X defined as features

# Checking the feature importance (coefficients) of the model
coefficients = pd.DataFrame({
    'Feature': X.columns,
    'Coefficient': model.coef_[0]
})

# Sort by the absolute value of the coefficients
coefficients['Absolute Coefficient'] = coefficients['Coefficient'].abs()
sorted_coefficients = coefficients.sort_values(by='Absolute Coefficient', ascending=False)

print(sorted_coefficients)

```

         Feature  Coefficient  Absolute Coefficient
    2         cp     0.885843              0.885843
    11        ca    -0.847620              0.847620
    1        sex    -0.835705              0.835705
    9    oldpeak    -0.765090              0.765090
    12      thal    -0.656935              0.656935
    7    thalach     0.653481              0.653481
    4       chol    -0.447601              0.447601
    8      exang    -0.420071              0.420071
    10     slope     0.343564              0.343564
    3   trestbps    -0.320016              0.320016
    6    restecg     0.140566              0.140566
    5        fbs    -0.062596              0.062596
    0        age    -0.006055              0.006055
    


```python
# Define a function that predicts heart disease based on changing cp values
def predict_with_fixed_features(cp_value):
    """
    This function predicts heart disease while keeping all other features at constant levels.
    The only changing feature is cp (chest pain type).
    """
    # Set features to fixed values
    # [age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal]
    new_sample = [
        [30, 0, cp_value, 120, 180, 0, 1, 170, 0, 0.0, 2, 0, 2]  # Fixed feature values
    ]
    
    # Scale the new sample using the same scaler
    new_sample_scaled = scaler.transform(new_sample)

    # Predict using the trained model
    prediction = model.predict(new_sample_scaled)

    # Output the prediction result
    if prediction[0] == 0:
        print(f"cp value = {cp_value}: The patient is predicted not to have heart disease.")
    else:
        print(f"cp value = {cp_value}: The patient is predicted to have heart disease.")

# Example: Checking predictions for different cp values
for cp_value in [0, 1]:  # cp values range from 0 to 3
    predict_with_fixed_features(cp_value)

```

    cp value = 0: The patient is predicted to have heart disease.
    cp value = 1: The patient is predicted to have heart disease.
    


```python

```
